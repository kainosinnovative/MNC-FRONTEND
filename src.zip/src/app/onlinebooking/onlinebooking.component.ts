import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinebooking',
  templateUrl: './onlinebooking.component.html',
  styleUrls: ['./onlinebooking.component.scss']
})
export class OnlinebookingComponent implements OnInit {

  constructor() {  }

  ngOnInit(): void {
  }

  cartype(){
    console.log("hiiiii1111");
}

}

